class Reference:

    def __init__(self, ref, label):
        self.ref = ref
        self.label = label
